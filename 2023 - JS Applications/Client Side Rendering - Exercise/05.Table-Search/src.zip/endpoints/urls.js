export let endpoints = {
    "users" : "http://localhost:3030/jsonstore/advanced/table"
}