export async function deleteBook(e){
    console.log(e.srcElement.id);
}