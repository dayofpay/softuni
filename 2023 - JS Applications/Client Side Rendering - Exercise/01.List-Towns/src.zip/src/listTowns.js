function listTowns(e) {
    e.preventDefault();
    let getTowns = document.getElementById('towns').value.split(", ");


    let getMainContainer = document.getElementById('root');


    for(let town of getTowns){
        getMainContainer.innerHTML+= `
        <ul>
            <li>${town}</li>
        </ul>
        `
    }

    
  }
  
  export { listTowns };
  