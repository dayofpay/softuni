export function toggleStatusCode(e) {
    const button = e.target;
    const statusDiv = button.nextElementSibling;
    statusDiv.style.display = statusDiv.style.display === 'none' ? 'inline' : 'none';
    button.textContent = statusDiv.style.display === 'none' ? 'Show status code' : 'Hide status code';
  }